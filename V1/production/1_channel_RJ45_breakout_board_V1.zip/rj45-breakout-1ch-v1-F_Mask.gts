G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2025-12-11T09:04:32-03:00*
G04 #@! TF.ProjectId,rj45-breakout-1ch-v1,726a3435-2d62-4726-9561-6b6f75742d31,V1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2025-12-11 09:04:32*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.925000X-0.925000X-0.925000X0.925000X-0.925000X0.925000X0.925000X-0.925000X0.925000X0*%
%ADD11C,3.700000*%
%ADD12C,3.450000*%
%ADD13RoundRect,0.425000X-0.425000X-0.425000X0.425000X-0.425000X0.425000X0.425000X-0.425000X0.425000X0*%
%ADD14C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X3380000Y6000000D03*
D11*
X8460000Y6000000D03*
X13540000Y6000000D03*
X18620000Y6000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X17354000Y22430000D03*
X4654000Y22430000D03*
D13*
X7444000Y19890000D03*
D14*
X8460000Y18110000D03*
X9476000Y19890000D03*
X10492000Y18110000D03*
X11508000Y19890000D03*
X12524000Y18110000D03*
X13540000Y19890000D03*
X14556000Y18110000D03*
G04 #@! TD*
M02*
