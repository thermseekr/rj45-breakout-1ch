G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-06-16T22:49:18-03:00*
G04 #@! TF.ProjectId,eumesmo-brk-1ch-v2,65756d65-736d-46f2-9d62-726b2d316368,V2.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-06-16 22:49:18*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.200000*%
%ADD11C,3.450000*%
%ADD12RoundRect,0.425000X-0.425000X-0.425000X0.425000X-0.425000X0.425000X0.425000X-0.425000X0.425000X0*%
%ADD13C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X6500000Y12500000D03*
X10000000Y7500000D03*
X13500000Y12500000D03*
X17000000Y7500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X17354000Y25430000D03*
X4654000Y25430000D03*
D12*
X7444000Y22890000D03*
D13*
X8460000Y21110000D03*
X9476000Y22890000D03*
X10492000Y21110000D03*
X11508000Y22890000D03*
X12524000Y21110000D03*
X13540000Y22890000D03*
X14556000Y21110000D03*
G04 #@! TD*
M02*
